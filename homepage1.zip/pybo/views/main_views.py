from flask import Blueprint,send_from_directory, render_template

from pybo.models import Question

bp = Blueprint('main', __name__, url_prefix='/')

HTML_DIR = r'C:\my_projects\homepage1\pybo\html'

@bp.route("/")
def index():
#    return send_from_directory(HTML_DIR, "index.html")
     return render_template('index.html')


@bp.route('/<path:name>') #127.0.0.1/img/a
def start(name):
    return send_from_directory('html', name)


