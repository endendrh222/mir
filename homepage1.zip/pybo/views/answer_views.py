from datetime import datetime

from flask import Blueprint, url_for, request, render_template, g, flash
from werkzeug.utils import redirect

from pybo import db
from ..forms import AnswerForm
from pybo.models import Question, Answer

from .auth_views import login_required

bp = Blueprint('answer', __name__, url_prefix='/answer')


@bp.route('/create/<int:question_id>', methods=('POST',))
@login_required
def create(question_id):
    form = AnswerForm()
    question = Question.query.get_or_404(question_id)
    if form.validate_on_submit():
        content = request.form['content']
        answer = Answer(content=content, create_date=datetime.now(), user=g.user)
        question.answer_set.append(answer)
        db.session.commit()
        return redirect('{}#answer_{}'.format(
            url_for('question.detail', question_id=question_id), answer.id))
    return render_template('question_detail.html', question=question, form=form)


@bp.route('/modify/<int:answer_id>', methods=('GET', 'POST'))
@login_required
def modify(answer_id):
    answer = Answer.query.get_or_404(answer_id)

    def has_edit_permission(user, answer):
        return user == answer.user

    # 권한 확인
    if not has_edit_permission(g.user, answer):
        flash('수정권한이 없습니다')
        return redirect('{}#answer_{}'.format(
            url_for('question.detail', question_id=answer.question.id), answer.id))

    # 폼 생성 (GET, POST 모두에서 사용)
    form = AnswerForm(obj=answer if request.method == 'GET' else None)

    # POST 처리
    if request.method == "POST" and form.validate_on_submit():
        form.populate_obj(answer)
        answer.modify_date = datetime.utcnow()  # 수정일시 저장 (utcnow 사용)
        db.session.commit()
        return redirect('{}#answer_{}'.format(
            url_for('question.detail', question_id=answer.question.id), answer.id))

    # GET 처리 (폼 렌더링)
    return render_template('answer_form.html', form=form)

@bp.route('/delete/<int:answer_id>')
@login_required
def delete(answer_id):
    answer = Answer.query.get_or_404(answer_id)
    question_id = answer.question.id

    # 권한 확인
    if not has_permission_to_delete(answer):
        flash('삭제권한이 없습니다')
        return redirect(url_for('question.detail', question_id=question_id))

    # 답변 삭제 처리
    db.session.delete(answer)
    db.session.commit()

    return redirect(url_for('question.detail', question_id=question_id))

def has_permission_to_delete(answer):
    """현재 사용자가 답변을 삭제할 권한이 있는지 확인하는 함수"""
    return g.user == answer.user
