from datetime import datetime

from flask import Blueprint, render_template, request, url_for, g, flash
from werkzeug.utils import redirect

from .. import db
from pybo.models import Question, Answer, User
from pybo.forms import QuestionForm, AnswerForm

from pybo.views.auth_views import login_required

bp = Blueprint('question', __name__, url_prefix='/',static_folder='static', static_url_path='/static')


@bp.route("/hello")
def hello():
    page = request.args.get('page', type=int, default=1)  # 페이지
    per_page = 10  # 페이지당 항목 수
    block_size = 10  # 페이지 블록 크기
    question_list = Question.query.order_by(Question.create_date.desc()).paginate(page=page, per_page=per_page)

    # 현재 페이지 블록 시작과 끝 계산
    current_block_start = ((page - 1) // block_size) * block_size + 1
    current_block_end = min(current_block_start + block_size - 1, question_list.pages)

    return render_template('question_list.html',
        question_list=question_list,
        current_block_start=current_block_start,
        current_block_end=current_block_end,
        block_size=block_size)

@bp.route('/detail/<int:question_id>/')
def detail(question_id):
    form = AnswerForm()
    question = Question.query.get_or_404(question_id)

    answers = Answer.query.filter_by(question_id=question_id).order_by(Answer.create_date.asc()).all()

    # return render_template('testtest.html', question=question, form=form)
    return render_template('question_detail.html', question=question, form=form, answers=answers)

@bp.route('/create/', methods=('GET', 'POST'))
@login_required
def create():
    form = QuestionForm()
    if request.method == 'POST' and form.validate_on_submit():
        question = Question(subject=form.subject.data, content=form.content.data,
                            create_date=datetime.now(), user=g.user)
        db.session.add(question)
        db.session.commit()
        return redirect(url_for('main.index'))
    return render_template( 'question_form.html', form=form)


@bp.route('/modify/<int:question_id>', methods=('GET', 'POST'))
@login_required
def modify(question_id):
    question = Question.query.get_or_404(question_id)

    # 권한 확인 (has_permission 함수 사용)
    if not has_permission(question):
        flash('수정 권한이 없습니다')
        return redirect(url_for('question.detail', question_id=question_id))

    form = QuestionForm(obj=question)  # 폼 생성 (POST 요청일 경우도 초기화 가능)

    if form.validate_on_submit():  # POST 요청 + 폼 유효성 검사
        form.populate_obj(question)
        question.modify_date = datetime.now()  # 수정일시 저장
        db.session.commit()
        return redirect(url_for('question.detail', question_id=question_id))

    return render_template('question/question_form.html', form=form)


@bp.route('/delete/<int:question_id>')
@login_required
def delete(question_id):
    question = Question.query.get_or_404(question_id)

    # 권한 확인 (has_permission 함수 사용)
    if not has_permission(question):
        flash('삭제 권한이 없습니다')
        return redirect(url_for('question.detail', question_id=question_id))

    # 권한이 있으면 삭제 진행
    db.session.delete(question)
    db.session.commit()
    return redirect(url_for('question._list'))

def has_permission(question):
    """현재 사용자가 질문 작성자인지 확인하는 함수"""
    return g.user == question.user

@bp.route('/list/')
def _list():
    page = request.args.get('page', type=int, default=1)
    kw = request.args.get('kw', type=str, default='')

    # 질문 목록 조회 및 페이지네이션 처리
    question_list = Question.query.order_by(Question.create_date.desc())
    if kw:
        search = '%%{}%%'.format(kw)
        sub_query = db.session.query(Answer.question_id, Answer.content, User.username) \
            .join(User, Answer.user_id == User.id).subquery()
        question_list = question_list \
            .join(User) \
            .outerjoin(sub_query, sub_query.c.question_id == Question.id) \
            .filter(Question.subject.ilike(search) |  # 질문제목
                    Question.content.ilike(search) |  # 질문내용
                    User.username.ilike(search) |  # 질문작성자
                    sub_query.c.content.ilike(search) |  # 답변내용
                    sub_query.c.username.ilike(search)  # 답변작성자
                    ) \
            .distinct()

    question_list = question_list.paginate(page=page, per_page=10)

    # 페이지네이션 블록 변수 계산
    block_size = 10  # 한 블록에 표시할 페이지 수
    current_block_start = (question_list.page - 1) // block_size * block_size + 1
    current_block_end = min(current_block_start + block_size - 1, question_list.pages)

    # 템플릿 렌더링 시 필요한 변수들 전달
    return render_template('question_list.html',
                           question_list=question_list,
                           page=page,
                           kw=kw,
                           block_size=block_size,
                           current_block_start=current_block_start,
                           current_block_end=current_block_end)